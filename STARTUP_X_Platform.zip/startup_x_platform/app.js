/* ==========================================================================
   STARTUP X — CORE APPLICATION ENGINE
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. CENTRAL CONFIGURATION
   -------------------------------------------------------------------------- */
const TELEGRAM_URL = "https://t.me/Mahadev0shiva";
const TELEGRAM_USERNAME = "@Mahadev0shiva";
const STARTER_URL = "https://t.me/Mahadev0shiva";
const BUILDER_URL = "https://t.me/Mahadev0shiva";
const FOUNDER_URL = "https://t.me/Mahadev0shiva";
const STORAGE_KEY = "startup_x_completed_resources";

/* --------------------------------------------------------------------------
   2. AUTHORITATIVE CURRICULUM DATASET (From Master Spreadsheet)
   -------------------------------------------------------------------------- */
const CURRICULUM_DATA = [
  {
    "id": "L01-01",
    "level": "Level 01",
    "levelNumber": 1,
    "module": "Foundations",
    "title": "Lecture 1-How to Start a Startup",
    "speaker": "Sam Altman, Dustin Moskovitz",
    "channel": "YC Root Access",
    "duration": "58m",
    "year": "2014",
    "scope": "All",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/watch?v=CBYhVcO4WgI"
  },
  {
    "id": "L02-01",
    "level": "Level 02",
    "levelNumber": 2,
    "module": "Discovery",
    "title": "How to Evaluate Startup Ideas",
    "speaker": "Kevin Hale",
    "channel": "Y Combinator",
    "duration": "26m 38s",
    "year": "2019",
    "scope": "Online/Hybrid",
    "capitalType": "Low Capital",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/watch?v=CBYhVcO4WgI"
  },
  {
    "id": "L02-02",
    "level": "Level 02",
    "levelNumber": 2,
    "module": "Validation",
    "title": "How to talk to customers with Rob Fitzpatrick (The Mom Test)",
    "speaker": "Rob Fitzpatrick",
    "channel": "Digital Product School",
    "duration": "1h 07m",
    "year": "2018",
    "scope": "All",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=How+to+talk+to+customers+with+Rob+Fitzpatrick+The+Mom+Test"
  },
  {
    "id": "L02-03",
    "level": "Level 02",
    "levelNumber": 2,
    "module": "Discovery",
    "title": "How to Talk to Users",
    "speaker": "Eric Migicovsky",
    "channel": "Y Combinator",
    "duration": "31m 37s",
    "year": "2019",
    "scope": "All",
    "capitalType": "",
    "type": "Deep Dive",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=How+to+Talk+to+Users+Eric+Migicovsky"
  },
  {
    "id": "L03-01",
    "level": "Level 03",
    "levelNumber": 3,
    "module": "Early Sales",
    "title": "How to Get Your First Customers",
    "speaker": "Gustaf Alströmer",
    "channel": "Y Combinator",
    "duration": "22m 54s",
    "year": "2022",
    "scope": "All",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/watch?v=hyYCn_kAngI"
  },
  {
    "id": "L03-02",
    "level": "Level 03",
    "levelNumber": 3,
    "module": "Sales",
    "title": "How To Sell by Tyler Bosmeny",
    "speaker": "Tyler Bosmeny",
    "channel": "Y Combinator",
    "duration": "52m",
    "year": "2018",
    "scope": "All",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=How+To+Sell+Tyler+Bosmeny+Y+Combinator"
  },
  {
    "id": "L04-01",
    "level": "Level 04",
    "levelNumber": 4,
    "module": "Pricing",
    "title": "How To Charge For Design-Value Based Pricing",
    "speaker": "Chris Do",
    "channel": "The Futur",
    "duration": "40m 41s",
    "year": "2019",
    "scope": "Services/B2B",
    "capitalType": "",
    "type": "Deep Dive",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=How+To+Charge+For+Design+Value+Based+Pricing+Chris+Do"
  },
  {
    "id": "L04-02",
    "level": "Level 04",
    "levelNumber": 4,
    "module": "Pricing",
    "title": "Startup Pricing 101",
    "speaker": "Kevin Hale",
    "channel": "Y Combinator",
    "duration": "19m 33s",
    "year": "2019",
    "scope": "Online/Hybrid",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/watch?v=jwXlo9gy_k4"
  },
  {
    "id": "L05-01",
    "level": "Level 05",
    "levelNumber": 5,
    "module": "Bootstrap",
    "title": "Customer funded business",
    "speaker": "John Mullins",
    "channel": "London Business School / TED",
    "duration": "15m 14s",
    "year": "2015",
    "scope": "All",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Customer+funded+business+John+Mullins"
  },
  {
    "id": "L05-02",
    "level": "Level 05",
    "levelNumber": 5,
    "module": "Finance",
    "title": "Managing Startup Finances",
    "speaker": "Kirsty Nathoo",
    "channel": "Y Combinator",
    "duration": "20m 00s",
    "year": "2019",
    "scope": "All",
    "capitalType": "Bootstrap / VC",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Managing+Startup+Finances+Kirsty+Nathoo"
  },
  {
    "id": "L11-01",
    "level": "Level 11",
    "levelNumber": 11,
    "module": "Bootstrap",
    "title": "Designing the Ideal Bootstrapped Business",
    "speaker": "Jason Cohen",
    "channel": "Rob Walling",
    "duration": "1h 05m",
    "year": "2019",
    "scope": "Online/SaaS",
    "capitalType": "Bootstrap",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Designing+the+Ideal+Bootstrapped+Business+Jason+Cohen"
  },
  {
    "id": "L11-02",
    "level": "Level 11",
    "levelNumber": 11,
    "module": "Bootstrap",
    "title": "The Stair Step Approach in Action",
    "speaker": "Rob Walling",
    "channel": "Rob Walling",
    "duration": "52m 42s",
    "year": "2022",
    "scope": "Online",
    "capitalType": "Low Capital",
    "type": "Deep Dive",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=The+Stair+Step+Approach+in+Action+Rob+Walling"
  },
  {
    "id": "L06-01",
    "level": "Level 06",
    "levelNumber": 6,
    "module": "Online",
    "title": "Pieter Levels: Programming, Viral AI Startups, Nomad Life",
    "speaker": "Pieter Levels",
    "channel": "Lex Fridman",
    "duration": "59m",
    "year": "2023",
    "scope": "Online",
    "capitalType": "Bootstrap / Solo",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Pieter+Levels+Programming+Viral+AI+Startups+Nomad+Life"
  },
  {
    "id": "L06-02",
    "level": "Level 06",
    "levelNumber": 6,
    "module": "Services",
    "title": "Secret to Running a $1M Solo Design Agency",
    "speaker": "Brett Williams",
    "channel": "The Futur",
    "duration": "1h 0m",
    "year": "2023",
    "scope": "Online/Agency",
    "capitalType": "",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Secret+to+Running+a+%241M+Solo+Design+Agency+Brett+Williams"
  },
  {
    "id": "L07-01",
    "level": "Level 07",
    "levelNumber": 7,
    "module": "Manufacturing",
    "title": "Lean Manufacturing with Paul Akers (Pt. 1)",
    "speaker": "Paul Akers",
    "channel": "UpFlip",
    "duration": "12m 29s",
    "year": "2020",
    "scope": "Offline",
    "capitalType": "Bootstrap",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Lean+Manufacturing+with+Paul+Akers"
  },
  {
    "id": "L15-01",
    "level": "Level 15",
    "levelNumber": 15,
    "module": "Distribution",
    "title": "FMCG Distribution Channel & Margins",
    "speaker": "Industry Expert",
    "channel": "4P-Beyond 4P's",
    "duration": "11m 23s",
    "year": "2022",
    "scope": "Offline",
    "capitalType": "Capital Intensive",
    "type": "Deep Dive",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=FMCG+Distribution+Channel+%26+Margins"
  },
  {
    "id": "L15-02",
    "level": "Level 15",
    "levelNumber": 15,
    "module": "Retail Hybrid",
    "title": "How Dmart's Business Strategy Made R. Damani Retail King",
    "speaker": "Think School",
    "channel": "Think School",
    "duration": "13m 44s",
    "year": "2021",
    "scope": "Hybrid/Retail",
    "capitalType": "Scale",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=How+Dmart%27s+Business+Strategy+Made+R.+Damani+Retail+King+Think+School"
  },
  {
    "id": "L07-02",
    "level": "Level 07",
    "levelNumber": 7,
    "module": "MSME Food",
    "title": "Balaji Wafers Founder Reveals Secrets of Beating Lays",
    "speaker": "Chandubhai Virani",
    "channel": "Not specified",
    "duration": "1h 20m",
    "year": "2024",
    "scope": "Offline",
    "capitalType": "Low Capital",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Balaji+Wafers+Founder+Reveals+Secrets+of+Beating+Lays+Josh+Talks"
  },
  {
    "id": "L10-01",
    "level": "Level 10",
    "levelNumber": 10,
    "module": "Traditional",
    "title": "Origin Story of Haldiram: An 85000Cr Empire",
    "speaker": "Think School",
    "channel": "Think School",
    "duration": "15m 12s",
    "year": "2021",
    "scope": "Hybrid/FMCG",
    "capitalType": "Bootstrap to Scale",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Origin+Story+of+Haldiram+An+85000Cr+Empire+Think+School"
  },
  {
    "id": "L12-01",
    "level": "Level 12",
    "levelNumber": 12,
    "module": "Marketing",
    "title": "How Pidilite's Strategy Made it a Goldmine Stock",
    "speaker": "Think School",
    "channel": "Think School",
    "duration": "13m 10s",
    "year": "2022",
    "scope": "Offline/B2B2C",
    "capitalType": "Scale",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/watch?v=cbTEAeteaI8"
  },
  {
    "id": "L14-01",
    "level": "Level 14",
    "levelNumber": 14,
    "module": "Bootstrap",
    "title": "Sridhar Vembu - Bootstrapper's Guide to $500M Rev",
    "speaker": "Sridhar Vembu",
    "channel": "Traction",
    "duration": "21m",
    "year": "2018",
    "scope": "Hybrid/SaaS",
    "capitalType": "Bootstrap",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Sridhar+Vembu+Bootstrapper%27s+Guide+to+%24500M+Rev"
  },
  {
    "id": "L11-03",
    "level": "Level 11",
    "levelNumber": 11,
    "module": "Fintech/India",
    "title": "The Zerodha Story - Nithin Kamath on Bootstrapping",
    "speaker": "Nithin Kamath",
    "channel": "Ashish Sinha Show",
    "duration": "36m 39s",
    "year": "2017",
    "scope": "Online Fintech",
    "capitalType": "Bootstrap",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=The+Zerodha+Story+Nithin+Kamath+on+Bootstrapping"
  },
  {
    "id": "L02-04",
    "level": "Level 02",
    "levelNumber": 2,
    "module": "Opportunity",
    "title": "How to Identify a Business Opportunity",
    "speaker": "Sanjeev Bikhchandani",
    "channel": "TED Talk",
    "duration": "17m 05s",
    "year": "2015",
    "scope": "All",
    "capitalType": "Bootstrap",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=How+to+Identify+a+Business+Opportunity+Sanjeev+Bikhchandani"
  },
  {
    "id": "L02-05",
    "level": "Level 02",
    "levelNumber": 2,
    "module": "Marketplaces",
    "title": "Building a Rs.95000 Crore Business (Info Edge)",
    "speaker": "Sanjeev Bikhchandani",
    "channel": "Prakhar Gupta",
    "duration": "1h 43m",
    "year": "2025",
    "scope": "Hybrid",
    "capitalType": "Bootstrap to Scale",
    "type": "Case Study",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Building+a+Rs+95000+Crore+Business+Info+Edge+Prakhar+Gupta"
  },
  {
    "id": "L10-02",
    "level": "Level 10",
    "levelNumber": 10,
    "module": "Operations",
    "title": "Lecture 14-How to Operate (Keith Rabois)",
    "speaker": "Keith Rabois",
    "channel": "YC Root Access",
    "duration": "46m 39s",
    "year": "2014",
    "scope": "Scale",
    "capitalType": "Growth",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Lecture+14+How+to+Operate+Keith+Rabois"
  },
  {
    "id": "L10-03",
    "level": "Level 10",
    "levelNumber": 10,
    "module": "Scaling",
    "title": "Brian Chesky Designing a 10-star Experience",
    "speaker": "Brian Chesky",
    "channel": "Stanford GSB",
    "duration": "55m 24s",
    "year": "2023",
    "scope": "Hybrid/Platform",
    "capitalType": "Scale",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Brian+Chesky+Designing+a+10-star+Experience"
  },
  {
    "id": "L12-02",
    "level": "Level 12",
    "levelNumber": 12,
    "module": "Strategy",
    "title": "Competition is for Losers with Peter Thiel",
    "speaker": "Peter Thiel",
    "channel": "Y Combinator",
    "duration": "50m 28s",
    "year": "2017",
    "scope": "All",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Competition+is+for+Losers+with+Peter+Thiel"
  },
  {
    "id": "L11-04",
    "level": "Level 11",
    "levelNumber": 11,
    "module": "Financing",
    "title": "Understanding SAFES & Priced Equity Rounds",
    "speaker": "Kirsty Nathoo",
    "channel": "Y Combinator",
    "duration": "Not specified",
    "year": "Not specified",
    "scope": "Not specified",
    "capitalType": "",
    "type": "Deep Dive",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Understanding+SAFES+%26+Priced+Equity+Rounds+Kirsty+Nathoo"
  },
  {
    "id": "L11-05",
    "level": "Level 11",
    "levelNumber": 11,
    "module": "Pitching",
    "title": "How to Pitch Your Startup",
    "speaker": "Kevin Hale",
    "channel": "Y Combinator",
    "duration": "27m 47s",
    "year": "2019",
    "scope": "All",
    "capitalType": "Angel/VC",
    "type": "Deep Dive",
    "essential": true,
    "videoLink": "https://www.youtube.com/watch?v=17XZGUX_9iM"
  },
  {
    "id": "L13-01",
    "level": "Level 13",
    "levelNumber": 13,
    "module": "Postmortem",
    "title": "The 9 Things That Kill Startups After Seed Rounds",
    "speaker": "Michael Seibel",
    "channel": "SaaStr",
    "duration": "44m 09s",
    "year": "2020",
    "scope": "All",
    "capitalType": "Post-Seed",
    "type": "Failure",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=The+9+Things+That+Kill+Startups+After+Seed+Rounds+Michael+Seibel"
  },
  {
    "id": "L13-02",
    "level": "Level 13",
    "levelNumber": 13,
    "module": "Failure",
    "title": "The Decline of Dunzo: What Happened?",
    "speaker": "Case Analysis",
    "channel": "Backstage w/ Millionaires",
    "duration": "7m 59s",
    "year": "2023",
    "scope": "Quick Commerce",
    "capitalType": "VC",
    "type": "Failure",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=The+Decline+of+Dunzo+What+Happened"
  },
  {
    "id": "L13-03",
    "level": "Level 13",
    "levelNumber": 13,
    "module": "Failure",
    "title": "Why are Indian Startups Failing Miserably?",
    "speaker": "Think School",
    "channel": "Think School",
    "duration": "16m 11s",
    "year": "2022",
    "scope": "Startups",
    "capitalType": "VC",
    "type": "Failure",
    "essential": true,
    "videoLink": "https://www.youtube.com/watch?v=k-51exmR9R4"
  },
  {
    "id": "L13-04",
    "level": "Level 13",
    "levelNumber": 13,
    "module": "Governance",
    "title": "What's Happening to BYJU'S? Case Study",
    "speaker": "Think School",
    "channel": "Think School",
    "duration": "20m 11s",
    "year": "2023",
    "scope": "Edtech/Offline",
    "capitalType": "Growth/Debt",
    "type": "Failure",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=What%27s+Happening+to+BYJU%27S+Case+Study+Think+School"
  },
  {
    "id": "L00-01",
    "level": "Level 00",
    "levelNumber": 0,
    "module": "Mistakes",
    "title": "Biggest Mistakes First Time Founders Make",
    "speaker": "Michael Seibel",
    "channel": "Y Combinator",
    "duration": "7m 03s",
    "year": "2019",
    "scope": "All",
    "capitalType": "",
    "type": "Core",
    "essential": true,
    "videoLink": "https://www.youtube.com/results?search_query=Biggest+Mistakes+First+Time+Founders+Make+Michael+Seibel"
  }
];

/* --------------------------------------------------------------------------
   3. 15-STAGE ROADMAP MASTER STRUCTURE
   -------------------------------------------------------------------------- */
const ROADMAP_DATA = [
  {
    "num": 0,
    "key": "Level 00",
    "name": "Founder Mindset & Pitfalls",
    "desc": "Critical first-time founder misconceptions, bias vs customer reality, and early operational traps.",
    "badge": "Pre-Requisite"
  },
  {
    "num": 1,
    "key": "Level 01",
    "name": "Startup Foundations",
    "desc": "Zero to one mechanics, co-founder alignment, and the foundational anatomy of building a company.",
    "badge": "Orientation"
  },
  {
    "num": 2,
    "key": "Level 02",
    "name": "Discovery & Validation",
    "desc": "Customer interview protocols (The Mom Test), opportunity evaluation, and idea demand testing.",
    "badge": "Validation"
  },
  {
    "num": 3,
    "key": "Level 03",
    "name": "Early Sales & First Customers",
    "desc": "Founder-led outbound calls, acquiring your first 10 paying customers, and closing conversations.",
    "badge": "Sales Engine"
  },
  {
    "num": 4,
    "key": "Level 04",
    "name": "Pricing & Value Design",
    "desc": "Value-based pricing vs cost-plus, tier architecture, price elasticity, and margin protection.",
    "badge": "Economics"
  },
  {
    "num": 5,
    "key": "Level 05",
    "name": "Finance & Bootstrapping",
    "desc": "Customer-funded business models, cash flow management, unit economics, and burn rate control.",
    "badge": "Cash Flow"
  },
  {
    "num": 6,
    "key": "Level 06",
    "name": "Online & Solo Models",
    "desc": "Micro-SaaS, viral AI products, solopreneur agencies, and hyper-lean software ventures.",
    "badge": "Solo & SaaS"
  },
  {
    "num": 7,
    "key": "Level 07",
    "name": "Manufacturing & MSME",
    "desc": "Lean production systems, shopfloor efficiency, regional physical product dominance.",
    "badge": "Physical Goods"
  },
  {
    "num": 8,
    "key": "Level 08",
    "name": "Product-Market Fit (PMF)",
    "desc": "Cohort retention metrics, user engagement benchmarks, and validating repeatable organic pull.",
    "badge": "Retention"
  },
  {
    "num": 9,
    "key": "Level 09",
    "name": "Go-To-Market & Growth Engines",
    "desc": "Scalable customer acquisition, non-paid distribution loops, and channel unit economics.",
    "badge": "GTM Engine"
  },
  {
    "num": 10,
    "key": "Level 10",
    "name": "Operations & Company Building",
    "desc": "Operating rhythms, designing 10-star customer experiences, and disciplined company scaling.",
    "badge": "Operations"
  },
  {
    "num": 11,
    "key": "Level 11",
    "name": "Capital Architecture & Funding",
    "desc": "Bootstrapping ladders, understanding SAFES, priced equity rounds, and pitch deck anatomy.",
    "badge": "Fundraising"
  },
  {
    "num": 12,
    "key": "Level 12",
    "name": "Moats, Strategy & Marketing",
    "desc": "Monopoly thinking, durable competitive advantages, and B2B2C distribution lock-in.",
    "badge": "Strategy"
  },
  {
    "num": 13,
    "key": "Level 13",
    "name": "Failure Postmortems & Governance",
    "desc": "The 9 post-seed startup killers, quick-commerce burn, and governance breakdowns.",
    "badge": "Risk Control"
  },
  {
    "num": 14,
    "key": "Level 14",
    "name": "Bootstrapping to Scale",
    "desc": "Sridhar Vembu's playbook for building enduring, high-profit scale without external VC.",
    "badge": "Scale Bootstrapping"
  },
  {
    "num": 15,
    "key": "Level 15",
    "name": "Mass Distribution & Hybrid Retail",
    "desc": "FMCG multi-tier margins, retail super-stockists, and negative working capital retail.",
    "badge": "Retail Distribution"
  }
];

/* --------------------------------------------------------------------------
   4. STATE MANAGEMENT
   -------------------------------------------------------------------------- */
let completedResourceIds = new Set();
let activeFilters = {
  search: "",
  level: "all",
  module: "all",
  type: "all",
  capital: "all",
  essentialOnly: false,
  sort: "default"
};

// Helper: Safe HTML escape to prevent XSS
function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/* --------------------------------------------------------------------------
   5. LOCAL STORAGE PROGRESS TRACKING
   -------------------------------------------------------------------------- */
function loadSavedProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        completedResourceIds = new Set(parsed);
      }
    }
  } catch (e) {
    console.warn("Could not read learning progress from localStorage", e);
  }
}

function saveProgressToStorage() {
  try {
    const arr = Array.from(completedResourceIds);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
  } catch (e) {
    console.warn("Could not write learning progress to localStorage", e);
  }
}

function toggleResourceComplete(id) {
  if (completedResourceIds.has(id)) {
    completedResourceIds.delete(id);
  } else {
    completedResourceIds.add(id);
  }
  saveProgressToStorage();
  updateProgressStatsUI();
  renderCurriculum();
  renderRoadmap();
}

function resetProgress() {
  if (completedResourceIds.size === 0) {
    alert("You have not marked any resources as completed yet.");
    return;
  }
  const confirmed = window.confirm("Are you sure you want to reset your learning progress? This will unmark all completed lessons on this device.");
  if (confirmed) {
    completedResourceIds.clear();
    saveProgressToStorage();
    updateProgressStatsUI();
    renderCurriculum();
    renderRoadmap();
  }
}

function updateProgressStatsUI() {
  const total = CURRICULUM_DATA.length;
  const completed = completedResourceIds.size;
  const remaining = Math.max(0, total - completed);
  const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

  const statCompleted = document.getElementById("statCompleted");
  const statTotal = document.getElementById("statTotal");
  const statRemaining = document.getElementById("statRemaining");
  const statPercentage = document.getElementById("statPercentage");
  const progressBarFill = document.getElementById("progressBarFill");
  const progressSummaryText = document.getElementById("progressSummaryText");
  const progressAria = document.getElementById("progressAria");

  if (statCompleted) statCompleted.textContent = completed;
  if (statTotal) statTotal.textContent = total;
  if (statRemaining) statRemaining.textContent = remaining;
  if (statPercentage) statPercentage.textContent = percentage + "%";
  if (progressBarFill) progressBarFill.style.width = percentage + "%";
  if (progressAria) progressAria.setAttribute("aria-valuenow", percentage);
  if (progressSummaryText) {
    progressSummaryText.textContent = `${completed} / ${total} Resources Completed (${percentage}% Complete) • Progress saved on device`;
  }
}

/* --------------------------------------------------------------------------
   6. RENDER 15-STAGE ROADMAP
   -------------------------------------------------------------------------- */
function renderRoadmap() {
  const container = document.getElementById("roadmapGridContainer");
  if (!container) return;

  container.innerHTML = "";

  ROADMAP_DATA.forEach(levelItem => {
    const levelResources = CURRICULUM_DATA.filter(r => r.levelNumber === levelItem.num);
    const resourceCount = levelResources.length;
    const completedCount = levelResources.filter(r => completedResourceIds.has(r.id)).length;

    const node = document.createElement("div");
    node.className = "roadmap-node";
    if (activeFilters.level === levelItem.key) {
      node.classList.add("active-filter");
    }

    node.setAttribute("role", "button");
    node.setAttribute("tabindex", "0");
    node.setAttribute("aria-label", `${levelItem.key}: ${levelItem.name}, ${resourceCount} resources`);

    node.innerHTML = `
      <div>
        <div class="roadmap-node-top">
          <span class="roadmap-level-tag">${escapeHtml(levelItem.key)}</span>
          <span class="roadmap-count-tag">${resourceCount} ${resourceCount === 1 ? 'lesson' : 'lessons'}</span>
        </div>
        <h3 class="roadmap-node-name">${escapeHtml(levelItem.name)}</h3>
        <p class="roadmap-node-desc">${escapeHtml(levelItem.desc)}</p>
      </div>
      <div class="roadmap-node-progress">
        <span>Progress: ${completedCount} / ${resourceCount}</span>
        <span style="color: var(--brand-cyan); font-weight: 700;">Filter →</span>
      </div>
    `;

    const handleClick = () => {
      filterByLevel(levelItem.key);
    };

    node.addEventListener("click", handleClick);
    node.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        handleClick();
      }
    });

    container.appendChild(node);
  });
}

/* --------------------------------------------------------------------------
   7. CURRICULUM FILTERING & RENDERING
   -------------------------------------------------------------------------- */
function populateDropdowns() {
  const levelSelect = document.getElementById("filterLevel");
  const moduleSelect = document.getElementById("filterModule");
  const typeSelect = document.getElementById("filterType");
  const capitalSelect = document.getElementById("filterCapital");

  const uniqueLevels = Array.from(new Set(CURRICULUM_DATA.map(r => r.level)))
    .sort((a, b) => parseInt(a.replace('Level ', '')) - parseInt(b.replace('Level ', '')));

  const uniqueModules = Array.from(new Set(CURRICULUM_DATA.map(r => r.module))).sort();
  const uniqueTypes = Array.from(new Set(CURRICULUM_DATA.map(r => r.type))).sort();
  const uniqueCapitals = Array.from(new Set(CURRICULUM_DATA.map(r => r.capitalType).filter(Boolean))).sort();

  if (levelSelect && levelSelect.options.length <= 1) {
    uniqueLevels.forEach(lvl => {
      const opt = document.createElement("option");
      opt.value = lvl;
      opt.textContent = lvl;
      levelSelect.appendChild(opt);
    });
  }

  if (moduleSelect && moduleSelect.options.length <= 1) {
    uniqueModules.forEach(mod => {
      const opt = document.createElement("option");
      opt.value = mod;
      opt.textContent = mod;
      moduleSelect.appendChild(opt);
    });
  }

  if (typeSelect && typeSelect.options.length <= 1) {
    uniqueTypes.forEach(t => {
      const opt = document.createElement("option");
      opt.value = t;
      opt.textContent = t;
      typeSelect.appendChild(opt);
    });
  }

  if (capitalSelect && capitalSelect.options.length <= 1) {
    uniqueCapitals.forEach(c => {
      const opt = document.createElement("option");
      opt.value = c;
      opt.textContent = c;
      capitalSelect.appendChild(opt);
    });
  }
}

function getFilteredResources() {
  const query = activeFilters.search.trim().toLowerCase();

  return CURRICULUM_DATA.filter(res => {
    if (query) {
      const textCorpus = [
        res.title,
        res.speaker,
        res.channel,
        res.module,
        res.level,
        res.scope,
        res.capitalType
      ].join(" ").toLowerCase();

      if (!textCorpus.includes(query)) return false;
    }

    if (activeFilters.level !== "all" && res.level !== activeFilters.level) {
      return false;
    }

    if (activeFilters.module !== "all" && res.module !== activeFilters.module) {
      return false;
    }

    if (activeFilters.type !== "all" && res.type !== activeFilters.type) {
      return false;
    }

    if (activeFilters.capital !== "all" && res.capitalType !== activeFilters.capital) {
      return false;
    }

    if (activeFilters.essentialOnly && !res.essential) {
      return false;
    }

    return true;
  });
}

function sortResources(list) {
  const sortMode = activeFilters.sort;
  const sorted = [...list];

  if (sortMode === "level-asc") {
    sorted.sort((a, b) => a.levelNumber - b.levelNumber || a.id.localeCompare(b.id));
  } else if (sortMode === "level-desc") {
    sorted.sort((a, b) => b.levelNumber - a.levelNumber || a.id.localeCompare(b.id));
  } else if (sortMode === "year-desc") {
    sorted.sort((a, b) => (parseInt(b.year) || 0) - (parseInt(a.year) || 0));
  } else if (sortMode === "year-asc") {
    sorted.sort((a, b) => (parseInt(a.year) || 9999) - (parseInt(b.year) || 9999));
  } else if (sortMode === "title-asc") {
    sorted.sort((a, b) => a.title.localeCompare(b.title));
  }
  return sorted;
}

function renderCurriculum() {
  const grid = document.getElementById("curriculumGrid");
  if (!grid) return;

  const filtered = getFilteredResources();
  const sorted = sortResources(filtered);

  const filteredCountEl = document.getElementById("filteredCount");
  const totalDatasetCountEl = document.getElementById("totalDatasetCount");
  if (filteredCountEl) filteredCountEl.textContent = sorted.length;
  if (totalDatasetCountEl) totalDatasetCountEl.textContent = CURRICULUM_DATA.length;

  renderActiveFilterChips();

  if (sorted.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          <line x1="8" y1="11" x2="14" y2="11"></line>
        </svg>
        <h3 class="empty-title">No matching resources found</h3>
        <p class="empty-desc">Try another search keyword or clear active filters to explore the full curriculum.</p>
        <button class="btn btn-primary btn-sm" onclick="clearAllFilters()">Clear Filters</button>
      </div>
    `;
    return;
  }

  grid.innerHTML = sorted.map(item => {
    const isDone = completedResourceIds.has(item.id);

    let typeClass = 'type-core';
    if (item.type === 'Deep Dive') typeClass = 'type-deep';
    else if (item.type === 'Case Study') typeClass = 'type-case';
    else if (item.type === 'Failure') typeClass = 'type-fail';

    return `
      <article class="resource-card ${isDone ? 'completed' : ''}" id="card-${item.id}" data-id="${item.id}">
        <div>
          <div class="resource-header">
            <span class="resource-level-badge">${escapeHtml(item.level)}</span>
            <span class="resource-module-badge">${escapeHtml(item.module)}</span>
            <span class="resource-id-tag">${escapeHtml(item.id)}</span>
          </div>

          <h3 class="resource-title">${escapeHtml(item.title)}</h3>

          <div class="resource-speakers">
            <div class="resource-speaker">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--brand-cyan);"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
              <span>${escapeHtml(item.speaker)}</span>
            </div>
            <div class="resource-channel">${escapeHtml(item.channel)}</div>
          </div>

          <div class="resource-meta-row">
            <span class="meta-tag">${escapeHtml(item.duration)}</span>
            <span class="meta-tag">${escapeHtml(item.year)}</span>
            <span class="meta-tag ${typeClass}">${escapeHtml(item.type)}</span>
            ${item.essential ? '<span class="meta-tag essential">★ Essential</span>' : ''}
            ${item.scope && item.scope !== '-' ? `<span class="meta-tag">Scope: ${escapeHtml(item.scope)}</span>` : ''}
            ${item.capitalType ? `<span class="meta-tag" style="color: #67E8F9;">${escapeHtml(item.capitalType)}</span>` : ''}
          </div>
        </div>

        <div class="resource-actions">
          <a href="${escapeHtml(item.videoLink)}" target="_blank" rel="noopener noreferrer" class="btn-watch" aria-label="Watch ${escapeHtml(item.title)}">
            <span>Watch Resource</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
          </a>
          <button class="btn-toggle-complete ${isDone ? 'is-done' : ''}" onclick="toggleResourceComplete('${item.id}')" title="${isDone ? 'Mark as incomplete' : 'Mark as completed'}" aria-label="Toggle completion status">
            ${isDone ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>' : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"></circle></svg>'}
          </button>
        </div>
      </article>
    `;
  }).join("");
}

function renderActiveFilterChips() {
  const container = document.getElementById("activeFilterChips");
  if (!container) return;

  const chips = [];

  if (activeFilters.search.trim()) {
    chips.push({ label: `Search: "${activeFilters.search.trim()}"`, clear: () => {
      activeFilters.search = "";
      const s = document.getElementById("curriculumSearch");
      if (s) s.value = "";
      renderCurriculum();
    } });
  }

  if (activeFilters.level !== "all") {
    chips.push({ label: `${activeFilters.level}`, clear: () => {
      activeFilters.level = "all";
      const l = document.getElementById("filterLevel");
      if (l) l.value = "all";
      renderCurriculum();
      renderRoadmap();
    } });
  }

  if (activeFilters.module !== "all") {
    chips.push({ label: `Module: ${activeFilters.module}`, clear: () => {
      activeFilters.module = "all";
      const m = document.getElementById("filterModule");
      if (m) m.value = "all";
      renderCurriculum();
    } });
  }

  if (activeFilters.type !== "all") {
    chips.push({ label: `Type: ${activeFilters.type}`, clear: () => {
      activeFilters.type = "all";
      const t = document.getElementById("filterType");
      if (t) t.value = "all";
      renderCurriculum();
    } });
  }

  if (activeFilters.capital !== "all") {
    chips.push({ label: `Capital: ${activeFilters.capital}`, clear: () => {
      activeFilters.capital = "all";
      const c = document.getElementById("filterCapital");
      if (c) c.value = "all";
      renderCurriculum();
    } });
  }

  if (activeFilters.essentialOnly) {
    chips.push({ label: `★ Essential Only`, clear: () => {
      activeFilters.essentialOnly = false;
      const e = document.getElementById("filterEssential");
      if (e) e.checked = false;
      renderCurriculum();
    } });
  }

  container.innerHTML = "";
  chips.forEach(c => {
    const chip = document.createElement("span");
    chip.className = "filter-chip";
    chip.innerHTML = `${escapeHtml(c.label)} <span class="filter-chip-remove" aria-label="Remove filter">×</span>`;
    chip.querySelector(".filter-chip-remove").addEventListener("click", c.clear);
    container.appendChild(chip);
  });
}

function filterByLevel(levelKey) {
  activeFilters.level = levelKey;
  const levelSelect = document.getElementById("filterLevel");
  if (levelSelect) levelSelect.value = levelKey;

  renderCurriculum();
  renderRoadmap();

  const el = document.getElementById("curriculum");
  if (el) el.scrollIntoView({ behavior: "smooth" });
}

function filterByModule(moduleName) {
  activeFilters.module = moduleName;
  const moduleSelect = document.getElementById("filterModule");
  if (moduleSelect) moduleSelect.value = moduleName;

  renderCurriculum();
  const el = document.getElementById("curriculum");
  if (el) el.scrollIntoView({ behavior: "smooth" });
}

function filterByScopeOrTerm(term) {
  activeFilters.search = term;
  const searchInput = document.getElementById("curriculumSearch");
  if (searchInput) searchInput.value = term;

  renderCurriculum();
  const el = document.getElementById("curriculum");
  if (el) el.scrollIntoView({ behavior: "smooth" });
}

function clearAllFilters() {
  activeFilters = {
    search: "",
    level: "all",
    module: "all",
    type: "all",
    capital: "all",
    essentialOnly: false,
    sort: "default"
  };

  const searchInput = document.getElementById("curriculumSearch");
  const levelSelect = document.getElementById("filterLevel");
  const moduleSelect = document.getElementById("filterModule");
  const typeSelect = document.getElementById("filterType");
  const capitalSelect = document.getElementById("filterCapital");
  const essentialCheckbox = document.getElementById("filterEssential");
  const sortSelect = document.getElementById("filterSort");

  if (searchInput) searchInput.value = "";
  if (levelSelect) levelSelect.value = "all";
  if (moduleSelect) moduleSelect.value = "all";
  if (typeSelect) typeSelect.value = "all";
  if (capitalSelect) capitalSelect.value = "all";
  if (essentialCheckbox) essentialCheckbox.checked = false;
  if (sortSelect) sortSelect.value = "default";

  renderCurriculum();
  renderRoadmap();
}

/* --------------------------------------------------------------------------
   8. FAQ ACCORDION INTERACTION
   -------------------------------------------------------------------------- */
function initFaq() {
  document.querySelectorAll('.faq-trigger').forEach(trigger => {
    trigger.addEventListener('click', () => {
      const item = trigger.parentElement;
      const content = trigger.nextElementSibling;
      const isOpen = item.classList.contains('active');

      document.querySelectorAll('.faq-item').forEach(i => {
        i.classList.remove('active');
        const c = i.querySelector('.faq-content');
        if (c) c.style.maxHeight = null;
        const t = i.querySelector('.faq-trigger');
        if (t) t.setAttribute('aria-expanded', 'false');
      });

      if (!isOpen) {
        item.classList.add('active');
        content.style.maxHeight = content.scrollHeight + 'px';
        trigger.setAttribute('aria-expanded', 'true');
      }
    });
  });
}

/* --------------------------------------------------------------------------
   9. MOBILE DRAWER NAVIGATION & ACCESSIBILITY
   -------------------------------------------------------------------------- */
function initNav() {
  const toggle = document.getElementById("menuToggle");
  const drawer = document.getElementById("mobileDrawer");

  if (!toggle || !drawer) return;

  const toggleMenu = () => {
    const isOpen = drawer.classList.contains("open");
    if (isOpen) {
      drawer.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      document.body.style.overflow = "";
    } else {
      drawer.classList.add("open");
      toggle.setAttribute("aria-expanded", "true");
      document.body.style.overflow = "hidden";
    }
  };

  toggle.addEventListener("click", toggleMenu);

  drawer.querySelectorAll("a").forEach(a => {
    a.addEventListener("click", () => {
      drawer.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      document.body.style.overflow = "";
    });
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && drawer.classList.contains("open")) {
      drawer.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      document.body.style.overflow = "";
    }
  });
}

/* --------------------------------------------------------------------------
   10. EVENT LISTENERS SETUP
   -------------------------------------------------------------------------- */
function setupEventListeners() {
  const searchInput = document.getElementById("curriculumSearch");
  const searchClear = document.getElementById("searchClearBtn");

  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      activeFilters.search = e.target.value;
      if (searchClear) {
        searchClear.style.display = e.target.value ? "block" : "none";
      }
      renderCurriculum();
    });
  }

  if (searchClear) {
    searchClear.addEventListener("click", () => {
      if (searchInput) {
        searchInput.value = "";
        searchInput.focus();
      }
      activeFilters.search = "";
      searchClear.style.display = "none";
      renderCurriculum();
    });
  }

  const levelSelect = document.getElementById("filterLevel");
  if (levelSelect) {
    levelSelect.addEventListener("change", (e) => {
      activeFilters.level = e.target.value;
      renderCurriculum();
      renderRoadmap();
    });
  }

  const moduleSelect = document.getElementById("filterModule");
  if (moduleSelect) {
    moduleSelect.addEventListener("change", (e) => {
      activeFilters.module = e.target.value;
      renderCurriculum();
    });
  }

  const typeSelect = document.getElementById("filterType");
  if (typeSelect) {
    typeSelect.addEventListener("change", (e) => {
      activeFilters.type = e.target.value;
      renderCurriculum();
    });
  }

  const capitalSelect = document.getElementById("filterCapital");
  if (capitalSelect) {
    capitalSelect.addEventListener("change", (e) => {
      activeFilters.capital = e.target.value;
      renderCurriculum();
    });
  }

  const sortSelect = document.getElementById("filterSort");
  if (sortSelect) {
    sortSelect.addEventListener("change", (e) => {
      activeFilters.sort = e.target.value;
      renderCurriculum();
    });
  }

  const essentialCheckbox = document.getElementById("filterEssential");
  if (essentialCheckbox) {
    essentialCheckbox.addEventListener("change", (e) => {
      activeFilters.essentialOnly = e.target.checked;
      renderCurriculum();
    });
  }

  document.querySelectorAll(".telegram-link-btn").forEach(btn => {
    btn.setAttribute("href", TELEGRAM_URL);
  });
}

/* --------------------------------------------------------------------------
   11. INITIALIZATION ON DOM READY
   -------------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  loadSavedProgress();
  populateDropdowns();
  updateProgressStatsUI();
  renderRoadmap();
  renderCurriculum();
  initFaq();
  initNav();
  setupEventListeners();
});
