# STARTUP X — Startup Operating System & Learning Platform

> **From Idea to Business**  
> *Startup Karna Hai? Pehle Confusion Nahi, Clarity Build Karo.*

---

## 📦 Package Contents

1. **`index.html`**  
   - Complete, standalone, production-ready website.
   - Everything (HTML, CSS, JavaScript, curriculum dataset, SVGs) is embedded in this single file.
   - Zero external library dependencies. Works completely offline or online.

2. **`styles.css`**  
   - Modular CSS design system (Dark SaaS aesthetic, tokens, responsive breakpoints, animations).

3. **`app.js`**  
   - Modular JavaScript engine containing the full curriculum array, filter/search logic, and progress tracking.

4. **`curriculum_dataset.json`**  
   - The authoritative JSON dataset containing all 34 resources across 14 levels with unique IDs (`L00-01` to `L15-02`).

5. **`startup_learning_master_sheet.xlsx`**  
   - The original master spreadsheet containing the curriculum source of truth.

---

## 🚀 How to Run

### Option 1: Direct Open
Double-click `index.html` or drag and drop it into any modern web browser (Chrome, Edge, Safari, Firefox). No build steps or server required.

### Option 2: Local HTTP Server (Optional)
```bash
python3 -m http.server 8000
```
Then visit `http://localhost:8000` in your browser.

### Option 3: Deploy to the Web (1-Click)
Deploy `index.html` directly to:
- **Vercel** / **Netlify** / **Cloudflare Pages** / **GitHub Pages**

---

## ⚡ Core Features

- **15-Stage Roadmap:** Level 00 to Level 15 navigation structure with dynamic lesson counts and progress.
- **Complete 34-Lesson Library:** Search by title, speaker, channel, level, or module.
- **Dynamic Filters:** Filter by Level, Module (28 categories), Type (Core, Deep Dive, Case Study, Failure), Capital Type, and Essential status.
- **Local Progress Tracking:** Mark lessons complete; progress persists across browser reloads via `localStorage`.
- **Business Model Explorer:** Interactive guide across SaaS, Agency, Manufacturing, FMCG, Retail, and Marketplaces.
- **Curated Case Studies:** Real breakdowns of Pieter Levels, Balaji Wafers, Haldiram, DMart, Zerodha, Zoho, etc.
- **Telegram Community Integration:** Centralized channel `@Mahadev0shiva` (`https://t.me/Mahadev0shiva`).
- **Zero WhatsApp References:** Completely clean, secure, and modern.
